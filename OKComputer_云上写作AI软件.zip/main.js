// AI写作助手主要JavaScript逻辑

// 全局变量
let currentProject = 'novel';
let writingStats = {
    wordCount: 1247,
    charCount: 5678,
    startTime: Date.now(),
    writingSpeed: 45
};

let aiSuggestions = [
    "建议增加更多关于飞船内部环境的描写，让读者更有代入感。",
    "可以考虑在对话中加入更多角色个性，让对话更加生动。",
    "尝试添加一些科幻元素的技术细节，增强故事的真实感。",
    "可以在场景转换处添加过渡段落，让故事更加连贯。",
    "建议为角色添加更多的内心独白，展现人物性格。"
];

let inspirationIdeas = [
    "在未知的星系中，团队发现了一个古老的外星文明遗迹...",
    "主角发现自己拥有特殊的能力，可以感知到维度裂缝...",
    "飞船的人工智能突然产生了自我意识，开始质疑人类的命令...",
    "探索队遇到了一个友好的外星种族，他们愿意分享先进的技术...",
    "在星球表面发现了神秘的符号，似乎是某种古老语言的记录...",
    "团队成员之间产生了分歧，关于是否应该继续深入探索...",
    "主角发现了一个关于自己身世的惊人秘密...",
    "飞船遭遇了时空扭曲，团队被困在了不同的时间线中..."
];

// 初始化函数
function initializeApp() {
    setupParticleBackground();
    setupTypingAnimation();
    updateStats();
    loadUserData();
    
    // 添加页面加载动画
    anime({
        targets: '.feature-card',
        translateY: [50, 0],
        opacity: [0, 1],
        delay: anime.stagger(200),
        duration: 800,
        easing: 'easeOutExpo'
    });
}

// 粒子背景设置
function setupParticleBackground() {
    const container = document.getElementById('particle-container');
    if (!container) return;
    
    // 使用p5.js创建粒子背景
    new p5((p) => {
        let particles = [];
        
        p.setup = () => {
            const canvas = p.createCanvas(container.offsetWidth, container.offsetHeight);
            canvas.parent(container);
            
            // 创建粒子
            for (let i = 0; i < 50; i++) {
                particles.push({
                    x: p.random(p.width),
                    y: p.random(p.height),
                    vx: p.random(-1, 1),
                    vy: p.random(-1, 1),
                    size: p.random(2, 6),
                    alpha: p.random(0.3, 0.8)
                });
            }
        };
        
        p.draw = () => {
            p.clear();
            
            // 绘制粒子
            particles.forEach(particle => {
                p.fill(246, 173, 85, particle.alpha * 255);
                p.noStroke();
                p.ellipse(particle.x, particle.y, particle.size);
                
                // 更新位置
                particle.x += particle.vx;
                particle.y += particle.vy;
                
                // 边界检测
                if (particle.x < 0 || particle.x > p.width) particle.vx *= -1;
                if (particle.y < 0 || particle.y > p.height) particle.vy *= -1;
            });
            
            // 绘制连接线
            for (let i = 0; i < particles.length; i++) {
                for (let j = i + 1; j < particles.length; j++) {
                    let dist = p.dist(particles[i].x, particles[i].y, particles[j].x, particles[j].y);
                    if (dist < 100) {
                        p.stroke(246, 173, 85, (1 - dist / 100) * 50);
                        p.strokeWeight(1);
                        p.line(particles[i].x, particles[i].y, particles[j].x, particles[j].y);
                    }
                }
            }
        };
        
        p.windowResized = () => {
            p.resizeCanvas(container.offsetWidth, container.offsetHeight);
        };
    });
}

// 打字机动画设置
function setupTypingAnimation() {
    const typingElement = document.querySelector('.typing-animation');
    if (!typingElement) return;
    
    const text = typingElement.textContent;
    typingElement.textContent = '';
    
    let i = 0;
    const typeWriter = () => {
        if (i < text.length) {
            typingElement.textContent += text.charAt(i);
            i++;
            setTimeout(typeWriter, 100);
        }
    };
    
    setTimeout(typeWriter, 1000);
}

// 更新写作统计
function updateStats() {
    const editor = document.getElementById('writing-editor');
    if (!editor) return;
    
    const text = editor.value;
    const words = text.trim().split(/\s+/).filter(word => word.length > 0);
    const characters = text.length;
    
    writingStats.wordCount = words.length;
    writingStats.charCount = characters;
    
    // 更新显示
    const wordCountEl = document.getElementById('word-count');
    const charCountEl = document.getElementById('char-count');
    const readTimeEl = document.getElementById('read-time');
    
    if (wordCountEl) wordCountEl.textContent = words.length.toLocaleString();
    if (charCountEl) charCountEl.textContent = characters.toLocaleString();
    if (readTimeEl) {
        const readTime = Math.ceil(words.length / 200); // 假设每分钟阅读200字
        readTimeEl.textContent = `约${readTime}分钟`;
    }
}

// 生成AI建议
function generateAISuggestions(text) {
    if (!text || text.length < 50) return;
    
    const suggestionsContainer = document.getElementById('ai-suggestions');
    if (!suggestionsContainer) return;
    
    // 模拟AI分析延迟
    setTimeout(() => {
        const randomSuggestions = aiSuggestions.slice(0, 2);
        suggestionsContainer.innerHTML = '';
        
        randomSuggestions.forEach((suggestion, index) => {
            const suggestionEl = document.createElement('div');
            suggestionEl.className = 'ai-suggestion p-3 rounded-lg';
            suggestionEl.innerHTML = `
                <p class="text-sm text-gray-700">${suggestion}</p>
                <button onclick="applySuggestion(${index})" class="text-xs text-orange-600 hover:text-orange-800 mt-2">应用建议</button>
            `;
            suggestionsContainer.appendChild(suggestionEl);
        });
    }, 1000);
}

// 项目相关函数
function selectProject(projectId) {
    currentProject = projectId;
    
    // 更新UI显示
    const projectItems = document.querySelectorAll('.document-item');
    projectItems.forEach(item => {
        item.classList.remove('bg-blue-50', 'border-blue-300');
    });
    
    event.currentTarget.classList.add('bg-blue-50', 'border-blue-300');
    
    // 加载项目内容
    loadProjectContent(projectId);
    
    // 显示选择动画
    anime({
        targets: event.currentTarget,
        scale: [1, 1.05, 1],
        duration: 300,
        easing: 'easeInOutQuad'
    });
}

function createNewProject() {
    const projectName = prompt('请输入项目名称：');
    if (!projectName) return;
    
    // 创建新项目
    const projectList = document.getElementById('project-list');
    const newProject = document.createElement('div');
    newProject.className = 'document-item p-3 rounded-lg border border-gray-200';
    newProject.onclick = () => selectProject('new-project');
    newProject.innerHTML = `
        <div class="flex items-center">
            <div class="w-3 h-3 bg-orange-500 rounded-full mr-3"></div>
            <div>
                <h4 class="font-medium text-gray-800">${projectName}</h4>
                <p class="text-sm text-gray-500">刚刚创建</p>
            </div>
        </div>
    `;
    
    projectList.insertBefore(newProject, projectList.firstChild);
    
    // 添加创建动画
    anime({
        targets: newProject,
        translateX: [-300, 0],
        opacity: [0, 1],
        duration: 500,
        easing: 'easeOutExpo'
    });
}

function loadProjectContent(projectId) {
    const editor = document.getElementById('writing-editor');
    const titleInput = document.getElementById('document-title');
    
    const projectContents = {
        'novel': {
            title: '科幻小说：星际迷航',
            content: '在遥远的未来，人类已经掌握了星际旅行的技术。主角李明是一名星际探索队的队长，他带领着团队前往未知的星系进行探索任务。\n\n这是他们第47次执行任务，目标是位于银河系边缘的一个神秘星系。据探测，这个星系中可能存在适合人类居住的行星。\n\n"所有人注意，我们即将进入目标星系。"李明通过通讯器向全队发出通知。飞船上的每个人都紧张而兴奋，因为这次任务可能会改变人类的历史。'
        },
        'essay': {
            title: '人工智能对现代社会的影响',
            content: '人工智能技术的发展正在深刻地改变着我们的社会。从工业生产到日常生活，AI的应用无处不在。\n\n首先，在工业领域，人工智能大大提高了生产效率。智能机器人可以24小时不间断工作，减少了人力成本，提高了产品质量。\n\n其次，在服务行业，AI技术也发挥着重要作用。智能客服、推荐系统、自动驾驶等技术正在改变着我们的生活方式。'
        },
        'blog': {
            title: '如何提高写作效率',
            content: '写作是一项需要持续练习的技能。想要提高写作效率，需要掌握一些实用的技巧。\n\n第一，建立固定的写作习惯。每天安排固定的时间进行写作，让大脑形成写作的条件反射。\n\n第二，学会使用大纲。在写作前先列出文章大纲，明确每个段落的要点，这样可以避免写作过程中的思路混乱。\n\n第三，善用写作工具。现代科技为我们提供了很多优秀的写作工具，合理利用这些工具可以大大提高写作效率。'
        },
        'report': {
            title: '2025年第一季度工作总结',
            content: '本季度，我们团队在公司领导的指导下，圆满完成了各项工作任务。现将主要工作情况总结如下：\n\n一、业务发展情况\n本季度新增客户15个，完成销售额500万元，超额完成季度目标的120%。\n\n二、团队建设情况\n新招聘员工3名，组织了2次专业技能培训，团队整体业务能力得到提升。\n\n三、存在的问题\n1. 客户维护工作需要加强\n2. 内部沟通机制有待完善\n3. 项目管理流程需要优化'
        }
    };
    
    const project = projectContents[projectId] || projectContents['novel'];
    
    if (titleInput) titleInput.value = project.title;
    if (editor) editor.value = project.content;
    
    updateStats();
}

// AI功能相关函数
function generateContent() {
    const editor = document.getElementById('writing-editor');
    if (!editor) return;
    
    const currentText = editor.value;
    const generatedContent = generateStoryContinuation(currentText);
    
    // 添加生成内容
    editor.value = currentText + '\n\n' + generatedContent;
    updateStats();
    
    // 显示生成动画
    const button = event.target;
    anime({
        targets: button,
        scale: [1, 1.1, 1],
        backgroundColor: ['#FED7AA', '#F6AD55', '#FED7AA'],
        duration: 600,
        easing: 'easeInOutQuad'
    });
}

function improveText() {
    const editor = document.getElementById('writing-editor');
    if (!editor) return;
    
    const selectedText = editor.value.substring(editor.selectionStart, editor.selectionEnd);
    if (!selectedText) {
        alert('请先选择要优化的文本');
        return;
    }
    
    const improvedText = improveSelectedText(selectedText);
    const fullText = editor.value;
    const newText = fullText.substring(0, editor.selectionStart) + improvedText + fullText.substring(editor.selectionEnd);
    
    editor.value = newText;
    updateStats();
}

function checkGrammar() {
    const editor = document.getElementById('writing-editor');
    if (!editor) return;
    
    // 模拟语法检查
    const issues = [
        { text: '所有人注意', suggestion: '所有人请注意', type: '语法' },
        { text: '紧张而兴奋', suggestion: '既紧张又兴奋', type: '表达' }
    ];
    
    if (issues.length > 0) {
        let message = '发现以下问题：\n';
        issues.forEach(issue => {
            message += `- ${issue.type}问题: "${issue.text}" → "${issue.suggestion}"\n`;
        });
        alert(message);
    } else {
        alert('没有发现语法问题！');
    }
}

function generateInspiration() {
    const inspirationContent = document.getElementById('inspiration-content');
    if (!inspirationContent) return;
    
    const randomInspiration = inspirationIdeas[Math.floor(Math.random() * inspirationIdeas.length)];
    inspirationContent.textContent = randomInspiration;
    
    // 添加生成动画
    anime({
        targets: inspirationContent,
        opacity: [0, 1],
        translateY: [20, 0],
        duration: 500,
        easing: 'easeOutExpo'
    });
}

function generateOutline() {
    const editor = document.getElementById('writing-editor');
    if (!editor) return;
    
    const currentText = editor.value;
    const outline = generateStoryOutline(currentText);
    
    // 在编辑器中添加大纲
    editor.value = currentText + '\n\n## 故事大纲\n' + outline;
    updateStats();
}

function analyzeTone() {
    const editor = document.getElementById('writing-editor');
    if (!editor) return;
    
    const text = editor.value;
    const tone = analyzeTextTone(text);
    
    alert(`文本语调分析：\n- 主要语调: ${tone.primary}\n- 情感色彩: ${tone.emotion}\n- 正式程度: ${tone.formality}`);
}

function findSynonyms() {
    const editor = document.getElementById('writing-editor');
    if (!editor) return;
    
    const selectedText = editor.value.substring(editor.selectionStart, editor.selectionEnd);
    if (!selectedText) {
        alert('请先选择要查找同义词的词语');
        return;
    }
    
    const synonyms = getSynonyms(selectedText);
    if (synonyms.length > 0) {
        alert(`"${selectedText}"的同义词：\n${synonyms.join(', ')}`);
    } else {
        alert('未找到同义词');
    }
}

// 应用建议
function applySuggestion(index) {
    const editor = document.getElementById('writing-editor');
    if (!editor) return;
    
    // 根据建议索引应用不同的改进
    switch(index) {
        case 0:
            // 添加环境描写
            const environmentText = '\n\n飞船内部充满了科技感的蓝光，控制台上的显示屏不断闪烁着各种数据。空气中弥漫着轻微的臭氧味道，这是离子引擎运行时产生的特征气味。';
            editor.value = editor.value + environmentText;
            break;
        case 1:
            // 改进对话
            const improvedDialogue = '\n\n"所有人注意，我们即将进入目标星系。"李明的声音通过通讯系统传遍整个飞船，语调中既有指挥官的威严，又难掩内心的激动。"检查所有系统，确保一切正常。"';
            editor.value = editor.value.replace(/"所有人注意，我们即将进入目标星系。"李明通过通讯器向全队发出通知。/, improvedDialogue);
            break;
    }
    
    updateStats();
    
    // 显示应用成功动画
    anime({
        targets: editor,
        backgroundColor: ['#ffffff', '#f0fff4', '#ffffff'],
        duration: 1000,
        easing: 'easeInOutQuad'
    });
}

// 文档操作函数
function saveDocument() {
    const editor = document.getElementById('writing-editor');
    const titleInput = document.getElementById('document-title');
    
    if (!editor || !titleInput) return;
    
    const document = {
        title: titleInput.value,
        content: editor.value,
        wordCount: writingStats.wordCount,
        lastModified: new Date().toISOString(),
        project: currentProject
    };
    
    // 保存到localStorage
    localStorage.setItem(`document_${currentProject}`, JSON.stringify(document));
    
    // 显示保存成功动画
    const saveButton = event.target;
    anime({
        targets: saveButton,
        scale: [1, 1.1, 1],
        backgroundColor: ['#F0FDF4', '#22C55E', '#F0FDF4'],
        duration: 800,
        easing: 'easeInOutQuad'
    });
    
    // 显示保存成功消息
    showNotification('文档已保存', 'success');
}

function exportDocument() {
    const editor = document.getElementById('writing-editor');
    const titleInput = document.getElementById('document-title');
    
    if (!editor || !titleInput) return;
    
    const content = editor.value;
    const title = titleInput.value;
    
    // 创建下载链接
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${title}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    showNotification('文档已导出', 'success');
}

// 辅助函数
function startWriting() {
    const editor = document.getElementById('writing-editor');
    if (editor) {
        editor.focus();
        editor.scrollIntoView({ behavior: 'smooth' });
    }
}

function showFeatures() {
    const featuresSection = document.querySelector('.py-16.bg-white');
    if (featuresSection) {
        featuresSection.scrollIntoView({ behavior: 'smooth' });
    }
}

function loadUserData() {
    // 从localStorage加载用户数据
    const savedData = localStorage.getItem('ai_writing_user_data');
    if (savedData) {
        const userData = JSON.parse(savedData);
        // 应用保存的用户设置
        console.log('加载用户数据:', userData);
    }
}

function showNotification(message, type = 'info') {
    // 创建通知元素
    const notification = document.createElement('div');
    notification.className = `fixed top-4 right-4 px-6 py-3 rounded-lg text-white z-50 ${
        type === 'success' ? 'bg-green-500' : 
        type === 'error' ? 'bg-red-500' : 'bg-blue-500'
    }`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // 显示动画
    anime({
        targets: notification,
        translateX: [300, 0],
        opacity: [0, 1],
        duration: 500,
        easing: 'easeOutExpo'
    });
    
    // 3秒后自动消失
    setTimeout(() => {
        anime({
            targets: notification,
            translateX: [0, 300],
            opacity: [1, 0],
            duration: 500,
            easing: 'easeInExpo',
            complete: () => {
                document.body.removeChild(notification);
            }
        });
    }, 3000);
}

// AI内容生成函数
function generateStoryContinuation(currentText) {
    const continuations = [
        '突然，飞船的警报系统响起了刺耳的警报声。"检测到未知能量源！"副驾驶小王紧张地报告。李明立即走到控制台前，查看着显示屏上的数据。\n\n"所有人保持冷静，按照应急预案行动。"李明沉声说道，同时快速分析着眼前的状况。',
        '就在这时，飞船外的景象发生了奇妙的变化。原本漆黑的太空中突然出现了一道绚丽的光带，像是某种神秘的力量在引导着他们。\n\n"这是什么？"团队成员们都惊呆了。李明仔细观察着这道光带，发现它似乎在指向某个特定的方向。',
        '飞船的通讯系统突然接收到了一段神秘的信号。经过一番解码，他们发现这似乎是一种欢迎的信息。\n\n"看来我们不是第一个来到这里的人类。"李明若有所思地说道。这个发现让整个团队都兴奋不已，同时也充满了疑问。'
    ];
    
    return continuations[Math.floor(Math.random() * continuations.length)];
}

function improveSelectedText(selectedText) {
    const improvements = {
        '所有人注意': '所有人请注意',
        '紧张而兴奋': '既紧张又兴奋',
        '通过通讯器': '通过通讯系统',
        '发出了通知': '下达了指令'
    };
    
    return improvements[selectedText] || selectedText;
}

function analyzeTextTone(text) {
    return {
        primary: '叙事性',
        emotion: '中性偏积极',
        formality: '中等正式'
    };
}

function getSynonyms(word) {
    const synonymMap = {
        '紧张': ['焦虑', '担忧', '不安'],
        '兴奋': ['激动', '振奋', '激昂'],
        '神秘': ['神奇', '奇异', '奥妙'],
        '探索': ['探险', '考察', '研究']
    };
    
    return synonymMap[word] || [];
}

function generateStoryOutline(text) {
    return `1. 引言部分\n   - 介绍主角和背景\n   - 设定故事基调\n\n2. 发展阶段\n   - 团队进入目标星系\n   - 发现异常情况\n   - 面临挑战和选择\n\n3. 高潮部分\n   - 关键事件的发生\n   - 角色成长和转变\n\n4. 结局部分\n   - 问题解决或新的发展\n   - 为未来故事埋下伏笔`;
}

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', initializeApp);

// 导出函数供HTML调用
window.startWriting = startWriting;
window.showFeatures = showFeatures;
window.selectProject = selectProject;
window.createNewProject = createNewProject;
window.updateStats = updateStats;
window.generateAISuggestions = generateAISuggestions;
window.generateContent = generateContent;
window.improveText = improveText;
window.checkGrammar = checkGrammar;
window.generateInspiration = generateInspiration;
window.generateOutline = generateOutline;
window.analyzeTone = analyzeTone;
window.findSynonyms = findSynonyms;
window.applySuggestion = applySuggestion;
window.saveDocument = saveDocument;
window.exportDocument = exportDocument;